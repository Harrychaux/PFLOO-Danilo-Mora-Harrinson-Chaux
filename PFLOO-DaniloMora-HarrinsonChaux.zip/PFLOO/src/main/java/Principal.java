public class Principal {
    public static void main(String[] args) {

        Archivo comunidad = new Archivo("comunidad.txt");
        comunidad.leerArchivo();

        Archivo resumen = new Archivo("resumen.txt");
        resumen.leerArchivo();

        Archivo gastos = new Archivo("Gastos.txt");
        gastos.leerArchivo();

        Archivo cuotas = new Archivo("cuotas.txt");
        cuotas.leerArchivo();

        Archivo propietarios = new Archivo("propietarios.txt");
        propietarios.leerArchivo();

        Archivo propiedades = new Archivo("propiedades.txt");
        propiedades.leerArchivo();
        System.out.println("-------------------------------------------------------------------------------------------------");
        System.out.println("--------------------alaborado por: Danilo Mora & Harrinson Chaux---------------------------------");
        System.out.println("-------------------------------------------------------------------------------------------------");
        System.out.println("|                                      LISTA DE COMUNIDAD                                       |");
        System.out.println("-------------------------------------------------------------------------------------------------");
        System.out.println("|      CODIGO      |            LUGAR                |                POBLACION                 |");
        System.out.println("-------------------------------------------------------------------------------------------------");
        for(Comunidad comunidad1 : comunidad.getListaComunidad().getComunidades()){
            comunidad1.print();
        }
        System.out.println("-------------------------------------------------------------------------------------------------");
        System.out.println("");
        System.out.println("");

        System.out.println("-------------------------------------------------------------------------------------------------");
        System.out.println("|                                      LISTA DE ZONA                                            |");
        System.out.println("-------------------------------------------------------------------------------------------------");
        System.out.println("|      IDENTIFICACION      |            ZONA                |              REPARTO              |");
        System.out.println("-------------------------------------------------------------------------------------------------");
        for (Zona zona : comunidad.getListaZona().getZonas()){
            zona.print();
        }
        System.out.println("-------------------------------------------------------------------------------------------------");

        System.out.println("");
        System.out.println("");
        System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("|                                                         LISTA DE PROPIEDAD                                                          |");
        System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("|  TIPO  |  CODIGO DE PROPIEDAD  |  AREA m2   |  CODIGO PROPIETARIO  |  IDENTIFICACION ZONA  |  NOMRE PROPIEDAD  |  TIPO PROPIEDAD    |");
        System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");
        for (Propiedad propiedad : comunidad.getListaPropiedad().getPropiedades()){
            propiedad.print();
        }
        System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");

        System.out.println("");
        System.out.println("");
        System.out.println("-------------------------------------------------------------------------------------------------");
        System.out.println("|                                    LISTA DE PROPIETARIOS                                      |");
        System.out.println("-------------------------------------------------------------------------------------------------");
        System.out.println("|   CODIGO   |         NOMBRE           |           LUGAR              |         CORREO         |");
        System.out.println("-------------------------------------------------------------------------------------------------");
        for (Propietario propietario : comunidad.getListaPropietario().getPropietarios()){
            propietario.print();
        }
        System.out.println("-------------------------------------------------------------------------------------------------");


        //APARTADO DEL ARCHIVO RESUMEN.TXT
        System.out.println("");
        System.out.println("");
        System.out.println("-------------------------------------------------------------");
        System.out.println("|                          RESUMEN                          |");
        System.out.println("-------------------------------------------------------------");
        System.out.println("|                   COMUNIDAD: 01 TREBOL                    |");
        System.out.println("-------------------------------------------------------------");
        System.out.println("|          COMUNIDAD          |           CANTIDAD          |");
        System.out.println("-------------------------------------------------------------");
        for (Resumen resumen1 : resumen.getListaResumen().getResumenes()){
            resumen1.print();
        }
        System.out.println("-------------------------------------------------------------");

        System.out.println("");
        System.out.println("");
        System.out.println("------------------------------------------------------------------------------------------");
        System.out.println("|                                       LISTA DE GASTOS                                  |");
        System.out.println("------------------------------------------------------------------------------------------");
        System.out.println("|   CODIGO   |         DESCRIPCION         |        IMPORTE       |    ZONA DE REPARTO   |");
        System.out.println("------------------------------------------------------------------------------------------");
        for (Gastos gastos1 : gastos.getListaGastos().getGasto()){
            gastos1.print();
        }
        System.out.println("------------------------------------------------------------------------------------------");

        System.out.println("");
        System.out.println("");
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("|                                                         LISTA DE CUOTAS PROPIEDADES                                                        |");
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("|                                               |              PORCENTAJES             |               IMPORTES               |              |");
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("|  CODIGO DE PROPIEDAD  |  NOMBRE PROPIETARIO   |     %E     |     %G     |     %C     |      E     |      G     |      C     |     TOTAL    |");
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------");
        for (Cuotas cuotas1 : cuotas.getListaCuotas().getCuota()){
            cuotas1.print();
        }
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------");

        System.out.println("");
        System.out.println("");
        System.out.println("------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("|                                                LISTA DE CUOTAS PROPIETARIOS                                                |");
        System.out.println("------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("|                                  |              PORCENTAJES             |               IMPORTES               |           |");
        System.out.println("------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("|  CODIGO  |  NOMBRE PROPIETARIO   |     %E     |     %G     |     %C     |      E     |      G     |      C     |   TOTAL   |");
        System.out.println("------------------------------------------------------------------------------------------------------------------------------");
        for (Cuotasp cuotasp1 : cuotas.getListaCuotasp().getCuotap()){
            cuotasp1.print();
        }
        System.out.println("------------------------------------------------------------------------------------------------------------------------------");



        System.out.println("");
        System.out.println("");
        System.out.println("-------------------------------------------------------------------------------------------------");
        System.out.println("|                                    LISTA DE PROPIETARIOS                                      |");
        System.out.println("-------------------------------------------------------------------------------------------------");
        System.out.println("|   CODIGO   |         NOMBRE           |           CORREO           |        PROPIEDADES       |");
        System.out.println("-------------------------------------------------------------------------------------------------");
        for (Propietarios propietarios1 : propietarios.getListaPropietarios().getPropietario()){
            propietarios1.print();
        }
        System.out.println("-------------------------------------------------------------------------------------------------");


        System.out.println("");
        System.out.println("");
        System.out.println("---------------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("|                                                         LISTA DE PROPIEDADES                                                                    |");
        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("|     CODIGO      |    AREA m2     |     CODIGO PROPIETARIO    |     NOMBRE PROPIETARIO     |     CUOTAS    |         INFORMACION ADICINAL        |");
        System.out.println("---------------------------------------------------------------------------------------------------------------------------------------------------");
        for (Propiedades propiedades1 : propiedades.getListaPropiedades().getPropiedad()){
            propiedades1.print();
        }
        System.out.println("---------------------------------------------------------------------------------------------------------------------------------------------------");
    }



}
