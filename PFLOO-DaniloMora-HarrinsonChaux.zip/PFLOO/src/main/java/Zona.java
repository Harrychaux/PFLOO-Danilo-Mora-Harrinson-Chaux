public class Zona {
    public  String identificacion, nombre, tipodereparto;

    public Zona(String identificacion, String nombre, String tipodereparto) {
        this.identificacion = identificacion;
        this.nombre = nombre;
        this.tipodereparto = tipodereparto;
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipodereparto() {
        return tipodereparto;
    }

    public void setTipodereparto(String tipodereparto) {
        this.tipodereparto = tipodereparto;
    }

    public void print(){
        System.out.println("|             "+identificacion+"            |          "+nombre+"                 "+tipodereparto);
    }
}
