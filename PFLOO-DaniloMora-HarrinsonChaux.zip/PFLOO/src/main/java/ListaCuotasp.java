import java.util.ArrayList;
import java.util.List;
public class ListaCuotasp {
    public List<Cuotasp>cuotap;

    public ListaCuotasp(){this.cuotap = new ArrayList<>();}

    public List<Cuotasp> getCuotap() {
        return cuotap;
    }

    public void setCuotap(List<Cuotasp> cuotap) {
        this.cuotap = cuotap;
    }

    public void agregarcuotasp(Cuotasp cuotasp){cuotap.add(cuotasp);}
}
