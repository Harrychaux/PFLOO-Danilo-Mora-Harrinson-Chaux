import java.util.ArrayList;
import java.util.List;
public class ListaPropietario {

    public  List<Propietario> propietarios;

    public ListaPropietario(){propietarios = new ArrayList<>();}

    public List<Propietario> getPropietarios() {
        return propietarios;
    }

    public void setPropietarios(List<Propietario> propietarios) {
        this.propietarios = propietarios;
    }

    public void  agregarpropietario(Propietario propietario){propietarios.add(propietario);}
}
