import java.util.ArrayList;
import java.util.List;

public class ListaZona {
    public List<Zona> zonas;
    public ListaZona(){
        zonas = new ArrayList<>();
    }

    public List<Zona> getZonas() {
        return zonas;
    }

    public void setZonas(List<Zona> zonas) {
        this.zonas = zonas;
    }
    public void agregarzona(Zona zona){zonas.add(zona);}
}
