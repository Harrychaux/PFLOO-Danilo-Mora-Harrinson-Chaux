public class Gastos {

    public String idgastos,descripcion,importe,zonareparto;

    public Gastos(String idgastos, String descripcion, String importe, String zonareparto) {
        this.idgastos = idgastos;
        this.descripcion = descripcion;
        this.importe = importe;
        this.zonareparto = zonareparto;
    }

    public String getIdgastos() {
        return idgastos;
    }

    public void setIdgastos(String idgastos) {
        this.idgastos = idgastos;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getImporte() {
        return importe;
    }

    public void setImporte(String importe) {
        this.importe = importe;
    }

    public String getZonareparto() {
        return zonareparto;
    }

    public void setZonareparto(String zonareparto) {
        this.zonareparto = zonareparto;
    }

    public void print(){
        System.out.println("|    "+idgastos+"    |        "+descripcion+"          "+importe+"           "+zonareparto+"          |");
    }
}
