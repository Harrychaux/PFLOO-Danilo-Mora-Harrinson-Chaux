import java.util.ArrayList;
import java.util.List;
public class ListaCuotas {

    public List<Cuotas>cuota;

    public ListaCuotas(){this.cuota = new ArrayList<>();}

    public List<Cuotas> getCuota() {
        return cuota;
    }

    public void setCuota(List<Cuotas> cuota) {
        this.cuota = cuota;
    }

    public void agregarcuotas(Cuotas cuotas){cuota.add(cuotas);}
}
