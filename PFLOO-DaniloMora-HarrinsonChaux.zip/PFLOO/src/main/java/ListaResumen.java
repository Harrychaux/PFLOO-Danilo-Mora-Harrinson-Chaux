import java.util.ArrayList;
import java.util.List;
public class ListaResumen {

    public List<Resumen> resumenes;

    public ListaResumen(){this.resumenes = new ArrayList<>();}

    public List<Resumen> getResumenes() {
        return resumenes;
    }

    public void setResumenes(List<Resumen> resumenes) {
        this.resumenes = resumenes;
    }

    public void agregarresumen(Resumen resumen){resumenes.add(resumen);}
}

