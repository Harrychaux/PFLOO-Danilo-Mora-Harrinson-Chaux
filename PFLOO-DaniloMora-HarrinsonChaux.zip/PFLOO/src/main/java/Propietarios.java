public class Propietarios {

    public String codigo,nombrep,correo,propiedades;

    public Propietarios(String codigo, String nombrep, String correo, String propiedades) {
        this.codigo = codigo;
        this.nombrep = nombrep;
        this.correo = correo;
        this.propiedades = propiedades;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombrep() {
        return nombrep;
    }

    public void setNombrep(String nombrep) {
        this.nombrep = nombrep;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getPropiedades() {
        return propiedades;
    }

    public void setPropiedades(String propiedades) {
        this.propiedades = propiedades;
    }

    public void print(){
        System.out.println("|     "+codigo+"     "+nombrep+"      "+correo+"          "+propiedades+"         ");
    }
}
