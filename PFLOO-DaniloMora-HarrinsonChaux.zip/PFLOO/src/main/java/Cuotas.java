public class Cuotas {

    public String codigopropiedad,nombrep,EP,GP,CP,EI,GI,CI,total;

    public Cuotas(String codigopropiedad, String nombrep, String EP, String GP, String CP, String EI, String GI, String CI, String total) {
        this.codigopropiedad = codigopropiedad;
        this.nombrep = nombrep;
        this.EP = EP;
        this.GP = GP;
        this.CP = CP;
        this.EI = EI;
        this.GI = GI;
        this.CI = CI;
        this.total = total;
    }

    public String getCodigopropiedad() {
        return codigopropiedad;
    }

    public void setCodigopropiedad(String codigopropiedad) {
        this.codigopropiedad = codigopropiedad;
    }

    public String getNombrep() {
        return nombrep;
    }

    public void setNombrep(String nombrep) {
        this.nombrep = nombrep;
    }

    public String getEP() {
        return EP;
    }

    public void setEP(String EP) {
        this.EP = EP;
    }

    public String getGP() {
        return GP;
    }

    public void setGP(String GP) {
        this.GP = GP;
    }

    public String getCP() {
        return CP;
    }

    public void setCP(String CP) {
        this.CP = CP;
    }

    public String getEI() {
        return EI;
    }

    public void setEI(String EI) {
        this.EI = EI;
    }

    public String getGI() {
        return GI;
    }

    public void setGI(String GI) {
        this.GI = GI;
    }

    public String getCI() {
        return CI;
    }

    public void setCI(String CI) {
        this.CI = CI;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public void print(){
        System.out.println("|          "+codigopropiedad+"          |    "+nombrep+"     "+EP+"    "+GP+"    "+CP+"   "+EI+""+GI+"    "+CI+"    "+total);
    }
}
