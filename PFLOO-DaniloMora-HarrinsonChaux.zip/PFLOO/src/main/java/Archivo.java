import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;
public class Archivo {
    public String nombre;
    public ListaComunidad listaComunidad;
    public ListaZona listaZona;
    public ListaPropiedad listaPropiedad;
    public ListaPropietario listaPropietario;
    public ListaResumen listaResumen;
    public ListaGastos listaGastos;
    public ListaCuotas listaCuotas;
    public ListaCuotasp listaCuotasp;
    public ListaPropietarios listaPropietarios;
    public ListaPropiedades listaPropiedades;

    public Archivo(String nombre) {
        this.nombre = nombre;
        listaComunidad = new ListaComunidad();
        listaZona = new ListaZona();
        listaPropiedad = new ListaPropiedad();
        listaPropietario = new ListaPropietario();
        listaResumen = new ListaResumen();
        listaGastos = new ListaGastos();
        listaCuotas = new ListaCuotas();
        listaCuotasp = new ListaCuotasp();
        listaPropietarios =  new ListaPropietarios();
        listaPropiedades = new ListaPropiedades();
    }

    public ListaPropiedades getListaPropiedades() {
        return listaPropiedades;
    }

    public void setListaPropiedades(ListaPropiedades listaPropiedades) {
        this.listaPropiedades = listaPropiedades;
    }

    public ListaPropietarios getListaPropietarios() {
        return listaPropietarios;
    }

    public void setListaPropietarios(ListaPropietarios listaPropietarios) {
        this.listaPropietarios = listaPropietarios;
    }

    public ListaCuotasp getListaCuotasp() {
        return listaCuotasp;
    }

    public void setListaCuotasp(ListaCuotasp listaCuotasp) {
        this.listaCuotasp = listaCuotasp;
    }

    public ListaCuotas getListaCuotas() {
        return listaCuotas;
    }

    public void setListaCuotas(ListaCuotas listaCuotas) {
        this.listaCuotas = listaCuotas;
    }

    public ListaGastos getListaGastos() {
        return listaGastos;
    }

    public void setListaGastos(ListaGastos listaGastos) {
        this.listaGastos = listaGastos;
    }

    public ListaResumen getListaResumen() {
        return listaResumen;
    }

    public void setListaResumen(ListaResumen listaResumen) {
        this.listaResumen = listaResumen;
    }

    public ListaPropietario getListaPropietario() {
        return listaPropietario;
    }

    public void setListaPropietario(ListaPropietario listaPropietario) {
        this.listaPropietario = listaPropietario;
    }

    public ListaPropiedad getListaPropiedad() {
        return listaPropiedad;
    }

    public void setListaPropiedad(ListaPropiedad listaPropiedad) {
        this.listaPropiedad = listaPropiedad;
    }

    public ListaZona getListaZona() {
        return listaZona;
    }

    public void setListaZona(ListaZona listaZona) {
        this.listaZona = listaZona;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ListaComunidad getListaComunidad() {
        return listaComunidad;
    }

    public void setListaComunidad(ListaComunidad listaComunidad) {
        this.listaComunidad = listaComunidad;
    }


    public void leerArchivo(){
        String linea;
        int apartado=0;
        StringBuffer identificacioncom,nombrecomunidad,poblacion;
        StringBuffer identificacionzon,nombrezona,tipodereparto;
        StringBuffer tipopro,codigopropiedad,m2,codigopropietario,lisporcentajezona,nombrepropiedad,tipopropiedad;
        StringBuffer codigo,nombrep,lugar,correo;
        StringBuffer numerozonas,cantidad;
        StringBuffer idgastos,descripcion,importe,zonareparto;
        StringBuffer EP,GP,CP,EI,GI,CI,total;
        StringBuffer propiedades;
        StringBuffer info,cuotas;

        try {
            BufferedReader br = new BufferedReader(new FileReader(nombre));
            while ((linea = br.readLine())!=null){

                linea = linea.trim();
                identificacioncom = new StringBuffer();
                nombrecomunidad = new StringBuffer();
                poblacion = new StringBuffer();
                identificacionzon = new StringBuffer();
                nombrezona = new StringBuffer();
                tipodereparto = new StringBuffer();
                tipopro = new StringBuffer();
                codigopropiedad = new StringBuffer();
                m2 = new StringBuffer();
                codigopropietario = new StringBuffer();
                lisporcentajezona = new StringBuffer();
                nombrepropiedad = new StringBuffer();
                tipopropiedad = new StringBuffer();

                nombrep = new StringBuffer();
                codigo = new StringBuffer();
                lugar = new StringBuffer();
                correo = new StringBuffer();

                numerozonas = new StringBuffer();
                cantidad = new StringBuffer();

                idgastos = new StringBuffer();
                descripcion = new StringBuffer();
                importe = new StringBuffer();
                zonareparto = new StringBuffer();

                EP = new StringBuffer();
                GP =new StringBuffer();
                CP = new StringBuffer();
                EI = new StringBuffer();
                GI= new StringBuffer();
                CI= new StringBuffer();
                total = new StringBuffer();

                propiedades = new StringBuffer();

                cuotas = new StringBuffer();
                info = new StringBuffer();

                if (linea.length()!=0){
                    //ARCHIVO TXT COMUNIDAD
                    if (linea.compareTo("#Comunidad")==0){
                        apartado=1;
                    }
                    else if (linea.compareTo("#Zona")==0){
                        apartado=2;
                    }
                    else if (linea.compareTo("#Propiedad")==0){
                        apartado=3;
                    }
                    else if (linea.compareTo("#Propietario")==0){
                        apartado=4;
                    }
                    //ARCHIVO TXT RESUMEN
                    else if (linea.compareTo("#Resumen")==0){
                        apartado=5;
                    }
                    //ARCHIVO TXT GASTOS
                    else if (linea.compareTo("#Gastos 2008")==0){
                        apartado=6;
                    }
                    //ARCHIVO TXT CUOTAS
                    else if (linea.compareTo("#CUOTASPORPROPIEDADES")==0){
                        apartado=7;
                    }
                    else if (linea.compareTo("#CUOTASPORPROPIETARIOS")==0){
                        apartado=8;
                    }
                    //ARCIVO TXT PROPIETARIOS
                    else if (linea.compareTo("#Propietarios")==0){
                        apartado=9;
                    }
                    //Achivo txt propiedades
                    else if (linea.compareTo("#Propiedades")==0){
                        apartado=10;
                    }
                    else{
                        if (apartado==1){
                            asignarvalores(linea,identificacioncom,nombrecomunidad,poblacion);
                            listaComunidad.agregarcomunidad(new Comunidad(identificacioncom.toString(),nombrecomunidad.toString(),poblacion.toString()));
                        }
                        else if (apartado==2){
                            asignarvalores(linea,identificacionzon,nombrezona,tipodereparto);
                            listaZona.agregarzona(new Zona(identificacionzon.toString(),nombrezona.toString(),tipodereparto.toString()));
                        }
                        else if (apartado==3){
                            asignarvalores(linea,tipopro,codigopropiedad,m2,codigopropietario,lisporcentajezona,nombrepropiedad,tipopropiedad);
                            listaPropiedad.agregarpropiedad(new Propiedad(tipopro.toString(),codigopropiedad.toString(),Double.parseDouble(m2.toString()),codigopropietario.toString(),lisporcentajezona.toString(),nombrepropiedad.toString(),tipopropiedad.toString()));
                        }

                        else if (apartado==4){
                            asignarvalores(linea,codigo,nombrep,lugar,correo);
                            listaPropietario.agregarpropietario(new Propietario(codigo.toString(),nombrep.toString(),lugar.toString(),correo.toString()));
                        }

                        else if (apartado==5){
                            asignarvalores(linea,numerozonas,cantidad);
                            listaResumen.agregarresumen(new Resumen(numerozonas.toString(),cantidad.toString()));

                        }

                        else if (apartado==6){
                            asignarvalores(linea,idgastos,descripcion,importe,zonareparto);
                            listaGastos.agregargastos(new Gastos(idgastos.toString(),descripcion.toString(),importe.toString(),zonareparto.toString()));
                        }
                        else if (apartado==7){
                            asignarvalores(linea,codigopropiedad,nombrep,EP,GP,CP,EI,GI,CI,total);
                            listaCuotas.agregarcuotas(new Cuotas(codigopropiedad.toString(),nombrep.toString(),EP.toString(),GP.toString(),CP.toString(),EI.toString(),GI.toString(),CI.toString(),total.toString()));
                        }
                        else if (apartado==8){
                            asignarvalores(linea,codigo,nombrep,EP,GP,CP,EI,GI,CI,total);
                            listaCuotasp.agregarcuotasp(new Cuotasp(codigo.toString(),nombrep.toString(),EP.toString(),GP.toString(),CP.toString(),EI.toString(),GI.toString(),CI.toString(),total.toString()));
                        }
                        else if(apartado==9){
                            asignarvalores(linea,codigo,nombrep,correo,propiedades);
                            listaPropietarios.agregarpropietarios(new Propietarios(codigo.toString(),nombrep.toString(),correo.toString(),propiedades.toString()));

                        }
                        else if(apartado==10){
                            asignarvalores(linea,codigo,m2,codigopropietario,nombrep,cuotas,info);
                            listaPropiedades.agregarpropiedades(new Propiedades(codigo.toString(),m2.toString(),codigopropietario.toString(),nombrep.toString(),cuotas.toString(),info.toString()));
                        }
                    }
                }
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void asignarvalores(String linea,StringBuffer ...arreglo){//en este caso estamos creando un arreglo de stringbuffer
        StringTokenizer token = new StringTokenizer(linea,";");
        for (StringBuffer e: arreglo) {
            e.append(token.nextToken().trim());
        }
    }
}
