public class Comunidad {
    public String identificacion, nombre, poblacion;

    public Comunidad(String identificacion, String nombre, String poblacion) {
        this.identificacion = identificacion;
        this.nombre = nombre;
        this.poblacion = poblacion;
    }

    public String getCodigo() {
        return identificacion;
    }

    public void setCodigo(String codigo) {
        this.identificacion = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPoblacion() {
        return poblacion;
    }

    public void setPoblacion(String poblacion) {
        this.poblacion = poblacion;
    }

    public  void print(){
        System.out.println("|         "+identificacion+"       |            "+nombre+"               |                "+poblacion+"                 |");

    }

}
