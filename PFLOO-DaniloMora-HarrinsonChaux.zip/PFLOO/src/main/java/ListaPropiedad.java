import java.util.ArrayList;
import java.util.List;

public class ListaPropiedad {
    public List<Propiedad> propiedades;
    public ListaPropiedad(){ propiedades=new ArrayList<>();}

    public List<Propiedad> getPropiedades() {
        return propiedades;
    }

    public void setPropiedades(List<Propiedad> propiedades) {
        this.propiedades = propiedades;
    }
    public void agregarpropiedad(Propiedad propiedad){propiedades.add(propiedad);}
}
