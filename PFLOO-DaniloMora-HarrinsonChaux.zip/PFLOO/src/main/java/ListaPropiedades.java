import java.util.ArrayList;
import java.util.List;

public class ListaPropiedades {

    public List<Propiedades>propiedad;

    public ListaPropiedades(){propiedad=new ArrayList<>();
    }

    public List<Propiedades> getPropiedad() {
        return propiedad;
    }

    public void setPropiedad(List<Propiedades> propiedad) {
        this.propiedad = propiedad;
    }

    public void agregarpropiedades(Propiedades propiedades){propiedad.add(propiedades);}
}
