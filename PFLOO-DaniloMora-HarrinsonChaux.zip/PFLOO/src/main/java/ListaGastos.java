import java.util.ArrayList;
import java.util.List;
public class ListaGastos {

    public List<Gastos>gasto;

    public ListaGastos(){this.gasto = new ArrayList<>();}

    public List<Gastos> getGasto() {
        return gasto;
    }

    public void setGasto(List<Gastos> gasto) {
        this.gasto = gasto;
    }

    public void agregargastos(Gastos gastos){gasto.add(gastos);}
}
