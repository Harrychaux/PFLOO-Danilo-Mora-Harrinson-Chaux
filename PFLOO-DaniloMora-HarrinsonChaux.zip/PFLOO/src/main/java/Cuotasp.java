public class Cuotasp {
    public String codigo,nombrep,EP,GP,CP,EI,GI,CI,total;

    public Cuotasp(String codigo, String nombrep, String EP, String GP, String CP, String EI, String GI, String CI, String total) {
        this.codigo = codigo;
        this.total=total;
        this.nombrep = nombrep;
        this.EP = EP;
        this.GP = GP;
        this.CP = CP;
        this.EI = EI;
        this.GI = GI;
        this.CI = CI;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombrep() {
        return nombrep;
    }

    public void setNombrep(String nombrep) {
        this.nombrep = nombrep;
    }

    public String getEP() {
        return EP;
    }

    public void setEP(String EP) {
        this.EP = EP;
    }

    public String getGP() {
        return GP;
    }

    public void setGP(String GP) {
        this.GP = GP;
    }

    public String getCP() {
        return CP;
    }

    public void setCP(String CP) {
        this.CP = CP;
    }

    public String getEI() {
        return EI;
    }

    public void setEI(String EI) {
        this.EI = EI;
    }

    public String getGI() {
        return GI;
    }

    public void setGI(String GI) {
        this.GI = GI;
    }

    public String getCI() {
        return CI;
    }

    public void setCI(String CI) {
        this.CI = CI;
    }


    public void print(){
        System.out.println("|    "+codigo+"    "+nombrep+"     "+EP+"     "+GP+"     "+CP+"   "+EI+"    "+GI+""+CI+"  "+total);
    }

}
