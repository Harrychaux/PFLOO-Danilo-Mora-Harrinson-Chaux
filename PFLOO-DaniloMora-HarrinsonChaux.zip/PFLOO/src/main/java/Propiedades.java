public class Propiedades {

    public String codigo,m2,codigopropietario,nombrep,cuotas,info;

    public Propiedades(String codigo, String codigopropietario, String m2, String nombrep, String cuotas, String info) {
        this.codigo = codigo;
        this.codigopropietario=codigopropietario;
        this.m2 = m2;
        this.nombrep = nombrep;
        this.cuotas = cuotas;
        this.info = info;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getCodigopropietario() {
        return codigopropietario;
    }

    public void setCodigopropietario(String codigopropietario) {
        this.codigopropietario = codigopropietario;
    }

    public String getM2() {
        return m2;
    }

    public void setM2(String m2) {
        this.m2 = m2;
    }

    public String getNombrep() {
        return nombrep;
    }

    public void setNombrep(String nombrep) {
        this.nombrep = nombrep;
    }

    public String getCuotas() {
        return cuotas;
    }

    public void setCuotas(String cuotas) {
        this.cuotas = cuotas;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public  void print(){
        System.out.println("|       "+codigo+"       "+codigopropietario+"             "+m2+"    "+""+nombrep+"    "+cuotas+" "+info);
    }
}
