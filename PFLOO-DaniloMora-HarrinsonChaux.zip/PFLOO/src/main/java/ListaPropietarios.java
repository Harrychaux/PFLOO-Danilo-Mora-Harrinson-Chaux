import java.util.ArrayList;
import java.util.List;
public class ListaPropietarios {

    public List<Propietarios>propietario;

    public ListaPropietarios(){this.propietario = new ArrayList<>();}

    public List<Propietarios> getPropietario() {
        return propietario;
    }

    public void setPropietario(List<Propietarios> propietario) {
        this.propietario = propietario;
    }

    public void agregarpropietarios(Propietarios propietarios){propietario.add(propietarios);}
}
