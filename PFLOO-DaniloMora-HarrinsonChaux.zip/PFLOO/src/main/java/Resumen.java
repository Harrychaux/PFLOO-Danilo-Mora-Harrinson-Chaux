public class Resumen {

    public String numerozonas,cantidad;

    public Resumen(String numerozonas, String cantidad) {
        this.numerozonas = numerozonas;
        this.cantidad = cantidad;
    }

    public String getNumerozonas() {
        return numerozonas;
    }

    public void setNumerozonas(String numerozonas) {
        this.numerozonas = numerozonas;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public void print(){
        System.out.println("|      "+numerozonas+"               "+cantidad);
    }
}
