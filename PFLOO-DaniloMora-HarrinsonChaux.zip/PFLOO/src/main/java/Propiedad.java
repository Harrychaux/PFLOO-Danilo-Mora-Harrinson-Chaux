public class Propiedad {
    public  String tipo, codigopropiedad, codigopropietario,nombrepropiedad,tipopropiedad,lisporcentajezona ;
    public double m2;

    public Propiedad(String tipo, String codigopropiedad, double m2, String codigopropietario,String lisporcentajezona, String nombrepropiedad, String tipopropiedad){
        this.tipo = tipo;
        this.codigopropiedad = codigopropiedad;
        this.m2 = m2;
        this.codigopropietario = codigopropietario;
        this.lisporcentajezona = lisporcentajezona;
        this.nombrepropiedad = nombrepropiedad;
        this.tipopropiedad = tipopropiedad;
    }

    public String getNombrepropiedad() {
        return nombrepropiedad;
    }

    public void setNombrepropiedad(String nombrepropiedad) {
        this.nombrepropiedad = nombrepropiedad;
    }

    public String getTipopropiedad() {
        return tipopropiedad;
    }

    public void setTipopropiedad(String tipopropiedad) {
        this.tipopropiedad = tipopropiedad;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCodigopropiedad() {
        return codigopropiedad;
    }

    public void setCodigopropiedad(String codigopropiedad) {
        this.codigopropiedad = codigopropiedad;
    }

    public String getLisporcentajezona() {
        return lisporcentajezona;
    }

    public void setLisporcentajezona(String lisporcentajezona) {
        this.lisporcentajezona = lisporcentajezona;
    }

    public double getM2() {
        return m2;
    }

    public void setM2(double m2) {
        this.m2 = m2;
    }

    public String getCodigopropietario() {
        return codigopropietario;
    }

    public void setCodigopropietario(String codigopropietario) {
        this.codigopropietario = codigopropietario;
    }


    public void print(){
        System.out.println("|    "+tipo+"   |          "+codigopropiedad+"          |   "+m2+"m2   |           "+codigopropietario+"         |          "+lisporcentajezona+"          |    "+nombrepropiedad+"    "+tipopropiedad);
    }
}
