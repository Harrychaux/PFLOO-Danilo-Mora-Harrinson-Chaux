public class Propietario {

    public  String codigo,nombrep,lugar,correo;

    public Propietario(String codigo, String nombrep, String lugar, String correo) {
        this.codigo = codigo;
        this.nombrep = nombrep;
        this.lugar = lugar;
        this.correo = correo;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombrep() {
        return nombrep;
    }

    public void setNombrep(String nombrep) {
        this.nombrep = nombrep;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public  void print(){
            System.out.println("|     "+codigo+      "     |     "+nombrep+"     |    "+lugar+"     |    "+correo);
    }
}
