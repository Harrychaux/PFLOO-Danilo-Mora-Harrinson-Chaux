import java.util.ArrayList;
import java.util.List;

public class ListaComunidad {
    public List<Comunidad> comunidades;

    public ListaComunidad() {
        this.comunidades = new ArrayList<>();
    }

    public List<Comunidad> getComunidades() {
        return comunidades;
    }

    public void setComunidades(List<Comunidad> comunidades) {
        this.comunidades = comunidades;
    }

    public void agregarcomunidad(Comunidad comunidad){comunidades.add(comunidad);}

}
